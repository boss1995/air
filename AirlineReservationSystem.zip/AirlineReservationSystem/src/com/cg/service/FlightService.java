package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.IDaoFlights;
import com.cg.entities.Booking;
import com.cg.entities.Flight;
import com.cg.entities.Users;
import com.cg.exception.QueryException;
@Service
@Transactional
public class FlightService implements IServiceFlight{
	@Autowired
	IDaoFlights dao;
	
	//getter and setter of dao
	public IDaoFlights getDao() {
		return dao;
	}


	public void setDao(IDaoFlights dao) {
		this.dao = dao;
	}


	@Override
	public Users addUser(Users user) {
		// TODO Auto-generated method stub
		return dao.addUser(user);
	}


	

	@Override
	public List<Flight> getAllFlights(String dc,String ac,String dd) throws QueryException{
		// TODO Auto-generated method stub
		return dao.getAllFlights(dc,ac,dd);
	}


	@Override
	public Users getUsers(String a, String b) throws QueryException{
		// TODO Auto-generated method stub
		return dao.getUsers(a, b);
	}


	@Override
	public List<Flight> getFlightlist(String flightNo) {
		// TODO Auto-generated method stub
		return dao.getFlightlist(flightNo);
	}


	@Override
	public Booking addBooking(Booking booking) {
		// TODO Auto-generated method stub
		return dao.addBooking(booking);
	}


	@Override
	public Users getUserInfo(int userId) {
		// TODO Auto-generated method stub
		return dao.getUserInfo(userId);
	}


	@Override
	public Users updateUser(Users u2) {
		// TODO Auto-generated method stub
		return dao.updateUser(u2);
	}
	
	@Override
	public Booking getBooking(int book) {
		// TODO Auto-generated method stub
		return dao.getBooking(book);
	}


	@Override
	public boolean deleteBooking(int bookingId) {
		// TODO Auto-generated method stub
		return dao.deleteBooking(bookingId);
	}


	@Override
	public Booking addBook(String flightId, int seats) {
		// TODO Auto-generated method stub
		return dao.addBook(flightId, seats);
	}


	@Override
	public Flight getFare(String fId) {
		// TODO Auto-generated method stub
		return dao.getFare(fId);
	}

}
